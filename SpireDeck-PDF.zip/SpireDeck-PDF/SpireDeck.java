import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


public class SpireDeck {


    public static void main(String[] args) throws IOException {

        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter the name of the deck file: "); //Just type example_deck.txt
        // or example_deck_void.txt for a voided deck
        String FileName = keyboard.nextLine();

        ArrayList<String> ValidCards = new ArrayList<>(); //Holds the cards that end up as valid
        ArrayList<String> InvalidCards = new ArrayList<>(); //Holds the cards that fail the checker
        int totalCards = 0;
        int totalCost = 0;
        int[] histogram = new int[7]; //Counts for cards from 0-6 to build the histogram (which I had to
        // google what a histogram was)

        Scanner fileReader = new Scanner(new File(FileName));

        while (fileReader.hasNextLine()) {
            String Line = fileReader.nextLine();
            String CardName = "";

            if (Line.length() == 0) {
                continue; //Skips empty rows
            }

            totalCards = totalCards + 1; //Adds to the amount of total cards

            int Colon = Line.lastIndexOf(":"); //Tells the code where the colon is
            boolean Valid = true;
            int Cost = 0;

            if (Colon == -1) {
                Valid = false;
            } else {
                CardName = Line.substring(0, Colon);
                String CostString = Line.substring(Colon + 1).trim();

                if (CardName.trim().length() == 0) {
                    Valid = false;
                }

                if (Valid) {
                    try {
                        Cost = Integer.parseInt(CostString);
                    } catch (NumberFormatException e) {
                        Valid = false;
                    }
                }

                if (Cost <= 0 || Cost > 6) {
                    Valid = false;
                }
            }

            if (Valid) {
                totalCost = totalCost + Cost;
                histogram[Cost] = histogram[Cost] + 1;
                ValidCards.add(CardName);
            } else {
                InvalidCards.add(CardName);
            }
        }
        fileReader.close();

        Random rand = new Random();
        long deckId = 100000000L + (long) (rand.nextDouble() * 900000000L);

        boolean isVoid = false;
        if (InvalidCards.size() > 10 || totalCards > 1000) {
            isVoid = true;
        }

        ArrayList<String> report = new ArrayList<>();
        report.add("Slay the Spire Deck Report");
        report.add("Deck ID: " + deckId);
        report.add("");

        if (isVoid) {
            report.add("VOID");
        } else {
            int validCardCount = totalCards - InvalidCards.size();
            report.add("Total cards in deck: " + validCardCount);
            report.add("Total energy cost: " + totalCost + " energy");
            report.add("\n");
            report.add("Valid Cards Counted:" + ValidCards.size());
            for (int i = 0; i < ValidCards.size(); i++) {
                report.add(ValidCards.get(i));
            }
            report.add("\n");
            report.add("Energy Cost Histogram:");
            for (int cost = 0; cost <= 6; cost++) {
                String bar = "";
                for (int i = 0; i < histogram[cost]; i++) {
                    bar = bar + "-";
                }
                report.add(cost + " energy | " + bar + " (" + histogram[cost] + ")");
            }
            report.add("");
            report.add("Invalid cards ignored: " + InvalidCards.size());
            for (int i = 0; i < InvalidCards.size(); i++) {
                report.add(InvalidCards.get(i));
            }
        }

        String outFileName;
        if (isVoid) {
            outFileName = "SpireDeck " + deckId + "(VOID).pdf";
        } else {
            outFileName = "SpireDeck " + deckId + ".pdf";
        }
        writePdf(report, outFileName);
        System.out.println("Report saved as: " + outFileName);
    }

    // This is something that I had no clue how to do beforehand, this was put together with a combination of
    // google and asking claude how to make a pdf. I'm still a little confused about how it works to be
    // honest, and I'm not sure if this is in violation of us using outside resources. If so I apologize,
    // and I'm fully willing to take a zero for this portion of the assignment. I just want to be
    // incredibly upfront about how this was something I didn't know how to do before this and looked to
    // outside resources to get this section of the code to actually run.
    public static void writePdf(ArrayList<String> report, String outFileName) throws IOException {

        int linesPerPage = 50;
        int pageCount = (report.size() / linesPerPage) + 1;

        ArrayList<String> pdfObjects = new ArrayList<>();

        // object 1 = catalog, object 2 = list of pages, object 3 = font
        pdfObjects.add("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

        String kids = "";
        for (int p = 0; p < pageCount; p++) {
            int pageObjNum = 4 + (p * 2);
            kids = kids + pageObjNum + " 0 R ";
        }
        pdfObjects.add("2 0 obj\n<< /Type /Pages /Kids [" + kids.trim() + "] /Count " + pageCount + " >>\nendobj\n");
        pdfObjects.add("3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Arial >>\nendobj\n");

        for (int p = 0; p < pageCount; p++) {
            int pageObjNum = 4 + (p * 2);
            int contentObjNum = pageObjNum + 1;

            String content = "BT\n/F1 15 Tf\n16 TL\n36 720 Td\n";
            boolean firstLine = true;
            int start = p * linesPerPage;
            int end = Math.min(start + linesPerPage, report.size());
            for (int i = start; i < end; i++) {
                if (!firstLine) {
                    content = content + "T*\n";
                }
                firstLine = false;
                String safe = report.get(i).replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
                content = content + "(" + safe + ") Tj\n";
            }
            content = content + "ET\n";

            pdfObjects.add(pageObjNum + " 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
                    + "/Resources << /Font << /F1 3 0 R >> >> /Contents " + contentObjNum + " 0 R >>\nendobj\n");
            pdfObjects.add(contentObjNum + " 0 obj\n<< /Length " + content.length() + " >>\nstream\n"
                    + content + "endstream\nendobj\n");
        }

        StringBuilder pdfText = new StringBuilder();
        pdfText.append("%PDF-1.4\n");

        int[] offsets = new int[pdfObjects.size()];
        for (int i = 0; i < pdfObjects.size(); i++) {
            offsets[i] = pdfText.length();
            pdfText.append(pdfObjects.get(i));
        }

        int xrefStart = pdfText.length();
        pdfText.append("xref\n0 " + (pdfObjects.size() + 1) + "\n");
        pdfText.append("0000000000 65535 f \n");
        for (int i = 0; i < offsets.length; i++) {
            pdfText.append(String.format("%010d 00000 n \n", offsets[i]));
        }
        pdfText.append("trailer\n<< /Size " + (pdfObjects.size() + 1) + " /Root 1 0 R >>\n");
        pdfText.append("startxref\n" + xrefStart + "\n%%EOF");

        FileOutputStream out = new FileOutputStream(outFileName);
        out.write(pdfText.toString().getBytes("ISO-8859-1"));
        out.close();
    }
}
